This is a really simple Twitter connection in Processing using OAuth. You can post a tweet, display tweets, search tweets, and probably more things with Twitter4J. 

Code is licensed under CC-BY. http://creativecommons.org/licenses/by/3.0/

If you do use the code in one of your projects, drop me an email! I would love to see it :)